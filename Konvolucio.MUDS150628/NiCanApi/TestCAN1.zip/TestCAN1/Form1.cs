﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using FJO_NICAN_Namespace;
using System.Runtime.InteropServices;


/* this solution provide C# wrapper for NI-CAN Frame API for device: NI-8473(no sync) 
 * 
 * 
 * this solution used 2 approaches: 
 * 1st:create c++ managed dll (which will include functions to be called later fro c#), wrapping unmanaged Nican.dll
 * so first c++ project fjoNICANDLL works like that, creating assembly fjoNICANDLL.dll
 * 
 * 2nd approach: create direct c# wrapper around unmanaged Nican.dll, and do everything in c#
 * in this aproach main problem is - sometime uncompatibility between managed c# data (which should be passed to c++ functions by pointer)
 * and unmanaged c++ functions. To solve that I used Marshal.AllocHGlobal to reserve unmanaged memory and filled that almost manually by needed data
 
 * * for me personaly 2nd is better.
 * SORRY FOR LOOSE CODE, may be it looks dirty, but at least it works
 * 
 * Serge
 * 
 * and yes: using, modifying, selling , trading, hacking etc of this code is allowed
 * 
 */

namespace TestCAN
{
    public partial class Form1 : Form
    {
        NI8473 Can0;
        public const uint MsgBufSize = 1024;
        public uint Can0ObjHandle = 0;
        public uint Can1ObjHandle = 0;
        StringBuilder ObjName0 = new StringBuilder("CAN0");
        StringBuilder ObjName1 = new StringBuilder("CAN1");
        int Status = 100;
        StringBuilder StatusStr = new StringBuilder((int)MsgBufSize);

        public uint CanID = 6;             // dest id
        //public uint CanIDext = CanID | NicanDll.NC_FL_CAN_ARBID_XTD;     // to make EXTended 29 bit frame  


        public Form1()
        {
            InitializeComponent();
            Can0 = new NI8473();

        }
        
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //--- call of my c++ func from fjoNICANDLL.dll--------
        private void button2_Click(object sender, EventArgs e)
        {
            int status = 100;
            //int x = NI8473.MyTest2();
            //int x = Can0.MyTest(2, 3);
            //uint status = NI8473.ReadCanID(0);

            //status = NI8473.ReadCanID_2(0);
            status = NI8473.MyConfig();
            MainTextBox.AppendText("Status:" + status.ToString());// + "\nStatus String:" + str.ToString());

        }
        // c++ Open-----------
        private void button12_Click(object sender, EventArgs e)
        {
            int status = 100;
            status = NI8473.MyOpen();
            MainTextBox.AppendText("Status:" + status.ToString());
        }

        // c++ write-----------
        private void button13_Click(object sender, EventArgs e)
        {
            int status = 100;
            status = NI8473.MyWrite();
            MainTextBox.AppendText("Status:" + status.ToString());
        }

        // c++ Close-----------
        private void button14_Click(object sender, EventArgs e)
        {
            int status = 100;
            status = NI8473.MyClose();
            MainTextBox.AppendText("Status:" + status.ToString());
        }

        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //---- direct call func from Nican.dll --------------
        private void button1_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;
            uint Result = 0;

            Status = NicanDll.ncGetHardwareInfo(1, 1, NicanDll.NC_ATTR_HW_SERIAL_NUM, 4, ref Result);
            CheckCANStatus(Status, CurMet, "ncGetHardwareInfo");
            MainTextBox.AppendText("NC_ATTR_HW_SERIAL_NUM: " + Result.ToString() + "\n");

        }



        //---- direct call func from Nican.dll --------------
        // ncConfig ncConfig
        private void button3_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;
            uint NumAttrs = 2;
            uint[] AttrIdList = {   NicanDll.NC_ATTR_BAUD_RATE, NicanDll.NC_ATTR_START_ON_OPEN };
            uint[] AttrValueList = { 1000000,  NicanDll.NC_FALSE };

            // ncConfig: Only the Baudrate and StartOnOpen attributes are used; other values are ignored.
            Status = NicanDll.ncConfig(ObjName0, NumAttrs, AttrIdList, AttrValueList);
            CheckCANStatus(Status, CurMet, "ncConfig 0");

            Status = NicanDll.ncConfig(ObjName1, NumAttrs, AttrIdList, AttrValueList);
            CheckCANStatus(Status, CurMet, "ncConfig 1");

        }

        //---- direct call func from Nican.dll --------------
        // OPEN OPEN OPEN OPEN OPEN OPEN OPEN
        private void button4_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;

            Status = NicanDll.ncOpenObject(ObjName0, ref Can0ObjHandle);
            CheckCANStatus(Status, CurMet, "ncOpenObject 0");

            Status = NicanDll.ncOpenObject(ObjName1, ref Can1ObjHandle);
            CheckCANStatus(Status, CurMet, "ncOpenObject 1");
        }

        //---- direct call func from Nican.dll --------------
        // GET GET GET GET GET GET GET GET GET GET GET GET GET
        private void button5_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;
            uint Attr = 0;

            // device CAN0 ------------------------------------------
            Status = NicanDll.ncGetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_HW_SERIAL_NUM, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_HW_SERIAL_NUM:" + Attr.ToString() + "\n");

            Status = NicanDll.ncGetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_BAUD_RATE, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_BAUD_RATE:"+Attr.ToString()+"\n");
            /*
            Status = NicanDll.ncGetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_READ_Q_LEN, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_READ_Q_LEN:" + Attr.ToString() + "\n");

            Status = NicanDll.ncGetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_WRITE_Q_LEN, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_WRITE_Q_LEN:" + Attr.ToString() + "\n");
            */
            Status = NicanDll.ncGetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SERIES2_FILTER_MODE, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_SERIES2_FILTER_MODE:" + Attr.ToString() + "\n");

            Status = NicanDll.ncGetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SERIES2_COMP, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_SERIES2_COMP:" + Attr.ToString() + "\n");

            Status = NicanDll.ncGetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SERIES2_MASK, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_SERIES2_MASK:" + Attr.ToString() + "\n");

            // device CAN1 ------------------------------------------
            Status = NicanDll.ncGetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_HW_SERIAL_NUM, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_HW_SERIAL_NUM:" + Attr.ToString() + "\n");

            Status = NicanDll.ncGetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_BAUD_RATE, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_BAUD_RATE:" + Attr.ToString() + "\n");
            /*
            Status = NicanDll.ncGetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_READ_Q_LEN, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_READ_Q_LEN:" + Attr.ToString() + "\n");

            Status = NicanDll.ncGetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_WRITE_Q_LEN, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_WRITE_Q_LEN:" + Attr.ToString() + "\n");
            */
            Status = NicanDll.ncGetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_SERIES2_FILTER_MODE, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_SERIES2_FILTER_MODE:" + Attr.ToString() + "\n");

            Status = NicanDll.ncGetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_SERIES2_COMP, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_SERIES2_COMP:" + Attr.ToString() + "\n");

            Status = NicanDll.ncGetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_SERIES2_MASK, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_SERIES2_MASK:" + Attr.ToString() + "\n");

        }

        //---- direct call func from Nican.dll --------------
        // SET SET SET SET SET SET SET SET SET SET SET SET SET SET SET SET SET SET
        private void button6_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;
            uint Attr = 0;

            // CAN0---------------------
            Attr = NicanDll.NC_FALSE;
            Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SINGLE_SHOT_TX, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_SINGLE_SHOT_TX:" + Attr.ToString() + "\n");
            /*
            Attr = 100;     // works??
            Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_READ_Q_LEN, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_READ_Q_LEN:" + Attr.ToString() + "\n");

            Attr = 100;     // works??
            Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_WRITE_Q_LEN, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_WRITE_Q_LEN:" + Attr.ToString() + "\n");
            */
            Attr = NicanDll.NC_FILTER_SINGLE_EXTENDED;
            Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SERIES2_FILTER_MODE, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_SERIES2_FILTER_MODE:" + Attr.ToString() + "\n");
            
            Attr = 0x00000000 << 3;
            Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SERIES2_MASK, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_SERIES2_MASK:" + Attr.ToString() + "\n");
            
            Attr = CanID << 3;
            Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SERIES2_COMP, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 0");
            MainTextBox.AppendText("NC_ATTR_SERIES2_COMP:" + Attr.ToString() + "\n");

            // CAN1---------------------
            Attr = NicanDll.NC_FALSE;
            Status = NicanDll.ncSetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_SINGLE_SHOT_TX, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_SINGLE_SHOT_TX:" + Attr.ToString() + "\n");
            /*
            Attr = 100;     // works??
            Status = NicanDll.ncSetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_READ_Q_LEN, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_READ_Q_LEN:" + Attr.ToString() + "\n");

            Attr = 100;     // works??
            Status = NicanDll.ncSetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_WRITE_Q_LEN, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_WRITE_Q_LEN:" + Attr.ToString() + "\n");
            */
            Attr = NicanDll.NC_FILTER_SINGLE_EXTENDED;
            Status = NicanDll.ncSetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_SERIES2_FILTER_MODE, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_SERIES2_FILTER_MODE:" + Attr.ToString() + "\n");

            Attr = 0x00000000 << 3;
            Status = NicanDll.ncSetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_SERIES2_MASK, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_SERIES2_MASK:" + Attr.ToString() + "\n");

            Attr = (CanID) << 3; //Attr |= 0x00000004;    //if RTRframe should be catched Attr |= 0x00000004; to set RTR bit (Manual p.11-16)
            Status = NicanDll.ncSetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_SERIES2_COMP, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncSetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_SERIES2_COMP:" + Attr.ToString() + "\n");

        }

        //---- direct call func from Nican.dll --------------
        // CLOSE CLOSE CLOSE CLOSE CLOSE CLOSE CLOSE CLOSE
        private void button7_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;

            Status = NicanDll.ncCloseObject(Can0ObjHandle);
            CheckCANStatus(Status, CurMet, "ncCloseObject 0");

            Status = NicanDll.ncCloseObject(Can1ObjHandle);
            CheckCANStatus(Status, CurMet, "ncCloseObject 1");

        }

        //---- direct call func from Nican.dll --------------
        // ncActionSTART ncActionSTART ncActionSTART
        private void button8_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;

            Status = NicanDll.ncAction(Can0ObjHandle, NicanDll.NC_OP_START, 0);
            CheckCANStatus(Status, CurMet, "ncActionSTART 0");

            Status = NicanDll.ncAction(Can1ObjHandle, NicanDll.NC_OP_START, 0);
            CheckCANStatus(Status, CurMet, "ncActionSTART 1");

        }

        //---- direct call func from Nican.dll --------------
        // ncActionSTOP ncActionSTOP ncActionSTOP
        private void button9_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;

            Status = NicanDll.ncAction(Can0ObjHandle, NicanDll.NC_OP_STOP, 0);
            CheckCANStatus(Status, CurMet, "ncActionSTOP 0");

            Status = NicanDll.ncAction(Can1ObjHandle, NicanDll.NC_OP_STOP, 0);
            CheckCANStatus(Status, CurMet, "ncActionSTOP 1");

        }

        //---- direct call func from Nican.dll --------------
        // ncActionRESET
        private void button10_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;

            Status = NicanDll.ncAction(Can0ObjHandle, NicanDll.NC_OP_RESET, 0);
            CheckCANStatus(Status, CurMet, "ncActionRESET 0");

            Status = NicanDll.ncAction(Can1ObjHandle, NicanDll.NC_OP_RESET, 0);
            CheckCANStatus(Status, CurMet, "ncActionRESET 1");

        }

        //---- direct call func from Nican.dll --------------
        // single write
        private void button11_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;
            NicanDll.NCTYPE_CAN_FRAME Frame = new NicanDll.NCTYPE_CAN_FRAME();
            
            Frame.ArbitrationId = CanID | NicanDll.NC_FL_CAN_ARBID_XTD; // to make EXTended 29 bit frame
            Frame.IsRemote = NicanDll.NC_FRMTYPE_DATA;  // or NC_FRMTYPE_REMOTE
            
            Frame.Data0 = 0;
            Frame.Data1 = 1;
            Frame.Data2 = 2;
            Frame.Data3 = 3;
            Frame.Data4 = 4;
            Frame.Data5 = 5;
            Frame.Data6 = 6;
            Frame.Data7 = 7;

            Frame.DataLength = 8;

            Status = NicanDll.ncWrite(Can0ObjHandle, NicanDll.CanFrameSize, ref Frame);
            CheckCANStatus(Status, CurMet, "ncWrite 0");

        }

        //---- direct call func from Nican.dll --------------
        private void WriteSequence(object sender, EventArgs e)
        {
            // config
            // open object
            // set attributes
            // make active
            // write and (or) read
            // close object

            string msg = "";
            string CurMet = MethodBase.GetCurrentMethod().Name;
            uint NumAttrs = 2;
            uint[] AttrIdList = /*new uint[NumAttrs];*/     {   NicanDll.NC_ATTR_BAUD_RATE, NicanDll.NC_ATTR_START_ON_OPEN };
            uint[] AttrValueList = /*new uint[NumAttrs];*/  {    1000000, NicanDll.NC_FALSE };
            uint Attr = 0;
            NicanDll.NCTYPE_CAN_FRAME Frame = new NicanDll.NCTYPE_CAN_FRAME();
            int FrameSize = 14;// Marshal.SizeOf(Frame.ArbitrationId) + Marshal.SizeOf(Frame.IsRemote) + Marshal.SizeOf(Frame.DataLength) + Frame.Data.Length;
            NicanDll.NCTYPE_CAN_STRUCT[] RxBuf = new NicanDll.NCTYPE_CAN_STRUCT[150];
            uint BufSize = 150 * NicanDll.CanStructSize;
            uint ActualDataSize = 100;


            try
            {
                /*
                AttrIdList[0] = NicanDll.NC_ATTR_BAUD_RATE;
                AttrValueList[0] = 125000;
                AttrIdList[1] = NicanDll.NC_ATTR_START_ON_OPEN;
                AttrValueList[1] = NicanDll.NC_FALSE;
                AttrIdList[2] = NicanDll.NC_ATTR_READ_Q_LEN;
                AttrValueList[2] = 0;
                AttrIdList[3] = NicanDll.NC_ATTR_WRITE_Q_LEN;
                AttrValueList[3] = 1;
                AttrIdList[4] = NicanDll.NC_ATTR_CAN_COMP_STD;
                AttrValueList[4] = 0;
                AttrIdList[5] = NicanDll.NC_ATTR_CAN_MASK_STD;
                AttrValueList[5] = NicanDll.NC_CAN_MASK_STD_DONTCARE;
                AttrIdList[6] = NicanDll.NC_ATTR_CAN_COMP_XTD;
                AttrValueList[6] = 0;
                AttrIdList[7] = NicanDll.NC_ATTR_CAN_MASK_XTD;
                AttrValueList[7] = NicanDll.NC_CAN_MASK_XTD_DONTCARE;
                */

                // config
                Status = NicanDll.ncConfig(ObjName0, NumAttrs, AttrIdList, AttrValueList);
                CheckCANStatus(Status, CurMet, "ncConfig");

                // open object
                Status = NicanDll.ncOpenObject(ObjName0, ref Can0ObjHandle);
                CheckCANStatus(Status, CurMet, "ncOpenObject");

                /*
                // set attributes
                Attr = 100;
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_READ_Q_LEN, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");

                Attr = 100;
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_WRITE_Q_LEN, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");

                */
                Attr = NicanDll.NC_FALSE; //NC_TRUE-send one single frame
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SINGLE_SHOT_TX, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");
                
                Attr = NicanDll.NC_FILTER_SINGLE_EXTENDED;
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SERIES2_FILTER_MODE, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");

                
                Attr = CanID << 3;     //id value to be compared with received frame_id
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SERIES2_COMP, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");

                Attr = 0x00000000 << 3;     //0-to be compared with COMP, 1-don't care(not compared)
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_SERIES2_MASK, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");
                

                Attr = 0;   //sw filter, disabled
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_CAN_COMP_STD, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");

                Attr = 0;   //sw filter, disabled
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_CAN_MASK_STD, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");


                Attr = 0;   //sw filter, disabled
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_CAN_COMP_XTD, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");

                Attr = 0;   //sw filter, disabled
                Status = NicanDll.ncSetAttribute(Can0ObjHandle, NicanDll.NC_ATTR_CAN_MASK_XTD, 4, ref Attr);
                CheckCANStatus(Status, CurMet, "ncSetAttribute");
                
                 
                // make active
                Status = NicanDll.ncAction(Can0ObjHandle, NicanDll.NC_OP_START, 0);
                CheckCANStatus(Status, CurMet, "ncAction Start");

                // prepare frame data
                Frame.ArbitrationId = CanID | NicanDll.NC_FL_CAN_ARBID_XTD; ; 
                Frame.IsRemote = NicanDll.NC_FRMTYPE_DATA;  // or NC_FRMTYPE_REMOTE
                Frame.Data0 = 0;
                Frame.Data1 = 1;
                Frame.Data2 = 2;
                Frame.Data3 = 3;
                Frame.Data4 = 4;
                Frame.Data5 = 5;
                Frame.Data6 = 6;
                Frame.Data7 = 7;
                Frame.DataLength = 8;
                FrameSize = 14;

                // write 
                Status = NicanDll.ncWrite(Can0ObjHandle, (uint)FrameSize, ref Frame);
                CheckCANStatus(Status, CurMet, "ncWrite");

                //Status = NicanDll.ncWaitForState(Can0ObjHandle, NicanDll.NC_ST_WRITE_SUCCESS, NicanDll.NC_DURATION_1SEC, ref CanState);
                //MainTextBox.AppendText("\nCanState:" + CanState.ToString() + "\n");
                //CheckCANStatus(Status, CurMet, "ncWaitForState");

                // read
                /*
                Status = NicanDll.ncReadMult(Can0ObjHandle, BufSize, ref RxBuf, ref ActualDataSize);
                CheckCANStatus(Status, CurMet, "ncReadMult");
                msg += "\n ActualDataSize:" + ActualDataSize.ToString() + "\n";
                MainTextBox.AppendText(msg);
                */


                if (MessageBox.Show("Stop process?", "???", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    // close object
                    Status = NicanDll.ncCloseObject(Can0ObjHandle);
                    CheckCANStatus(Status, CurMet, "ncCloseObject");
                }
                 
            }
            catch (ApplicationException appex)
            {
                string msg1 = "ERROR occured:\n" + appex.Message;
                MessageBox.Show(msg1);
            }


        }

        // check of status, returned by NI-CAN function 
        public void CheckCANStatus(int Status, string MetName, string NicanName )
        {
            string msg = "\nMethod: " + MetName + " Nican: " + NicanName;
            StringBuilder StatusStr = new StringBuilder((int)MsgBufSize);
            // status ok
            if (Status == 0)
            {
                msg += " OK Status:" + Status.ToString() + "\n";
                MainTextBox.AppendText(msg);
                return;
            }
            // status - warning
            if (Status > 0)
            {
                NicanDll.ncStatusToString(Status, MsgBufSize, StatusStr);
                msg += " WARNING Status:" + Status.ToString() + " Status Msg:" + StatusStr.ToString() + "\n";
                MainTextBox.AppendText(msg);
                return;
            }
            else    //status - error
            {
                NicanDll.ncStatusToString(Status, MsgBufSize, StatusStr);
                msg += " ERROR Status:" + Status.ToString() + " Status Msg:" + StatusStr.ToString() + "\n";
                MainTextBox.AppendText(msg);
                //throw new ApplicationException(msg);
            }
        }

        //---read mutiple------------------------------------------------------------------------------------------
        private void button16_Click(object sender, EventArgs e)
        {
            string msg = "";
            string CurMet = MethodBase.GetCurrentMethod().Name;
            uint RxBufSize = 150;
            uint RxBufSizeBytes = RxBufSize * NicanDll.CanStructSize;
            NicanDll.NCTYPE_CAN_STRUCT[] RxBuf = new NicanDll.NCTYPE_CAN_STRUCT[RxBufSize];
            NicanDll.NCTYPE_CAN_STRUCT RxMsg = new NicanDll.NCTYPE_CAN_STRUCT();
            uint ActualDataSize = 100;
            IntPtr RxBufIntPtr;
            int FrameOffset;


            // 2nd approach
            RxBufIntPtr = Marshal.AllocHGlobal((int)RxBufSizeBytes);        // reserve block of memory and get pointer to it
            Status = NicanDll.ncReadMult(Can1ObjHandle, RxBufSizeBytes, RxBufIntPtr, ref ActualDataSize);

            CheckCANStatus(Status, CurMet, "ncReadMult 1");
            MainTextBox.AppendText("\n ActualDataSize:" + ActualDataSize.ToString() + "\n");
            MainTextBox.AppendText("\n InPtr size(bytes):" + IntPtr.Size.ToString() + "\n");
            MainTextBox.AppendText("\n InPtr address:" + RxBufIntPtr.ToString("X") + "\n");

            if (ActualDataSize != 0)
            {
                int NumberOfFrames = (int)(ActualDataSize / NicanDll.CanStructSize);
                MainTextBox.AppendText("\n NumberOfFrames:" + NumberOfFrames.ToString() + "\n"); ;
                
                for (int i = 0; i < NumberOfFrames; i++ )
                {
                    FrameOffset = (int)( i * NicanDll.CanStructSize);

                    // read data from reserved memory block
                    RxMsg.TimeStamp     = (ulong)Marshal.ReadInt64(RxBufIntPtr, FrameOffset + 0);
                    RxMsg.ArbitrationId = (uint) Marshal.ReadInt32(RxBufIntPtr, FrameOffset + 8);
                    RxMsg.FrameType     = (byte) Marshal.ReadByte(RxBufIntPtr,  FrameOffset + 12);
                    RxMsg.DataLength    = (byte) Marshal.ReadByte(RxBufIntPtr,  FrameOffset + 13);
                    RxMsg.Data64        = (ulong)Marshal.ReadInt64(RxBufIntPtr, FrameOffset + 14);
                    RxBuf[i] = RxMsg;

                    MainTextBox.AppendText("\n ----------------------------------------------------\n");
                    MainTextBox.AppendText("\n Timestamp:"      + RxMsg.TimeStamp.ToString("X") + "\n");
                    MainTextBox.AppendText("\n ArbitrationId:"  + RxMsg.ArbitrationId.ToString("X") + "\n");
                    MainTextBox.AppendText("\n FrameType:"      + RxMsg.FrameType.ToString() + "\n");
                    MainTextBox.AppendText("\n DataLength:"     + RxMsg.DataLength.ToString() + "\n");
                    MainTextBox.AppendText("\n Data64:"         + RxMsg.Data64.ToString("X") + "\n");
                    MainTextBox.AppendText("\n Data7:"          + RxMsg.Data7.ToString() + "\n");
                }
            }


            /* 
             * 1st approach, RTI conflicts bw managed and unmanaged types, RxBuf 
            unsafe
            {
                fixed (NicanDll.NCTYPE_CAN_STRUCT* RxBufPtr = RxBuf)
                {
                    RxBufIntPtr = (IntPtr)RxBufPtr;
                    //Status = NicanDll.ncReadMult(Can1ObjHandle, RxBufSize, ref RxBuf, ref ActualDataSize);
                    Status = NicanDll.ncReadMult(Can1ObjHandle, RxBufSizeBytes, RxBufIntPtr, ref ActualDataSize);
                }// fixed
            }

            if (ActualDataSize != 0)
            {
                int NumberOfFrames = (int)(ActualDataSize / NicanDll.CanStructSize);
                MainTextBox.AppendText("\n NumberOfFrames:" + NumberOfFrames.ToString() + "\n"); ;
                
                for (int i = 0; i < NumberOfFrames; i++ )
                {
                    MainTextBox.AppendText("\n Timestamp:" + RxBuf[i].TimeStamp.ToString("X") + "\n");
                    MainTextBox.AppendText("\n ArbitrationId:" + RxBuf[i].ArbitrationId.ToString("X") + "\n");
                    MainTextBox.AppendText("\n FrameType:" + RxBuf[i].FrameType.ToString() + "\n");
                    MainTextBox.AppendText("\n DataLength:" + RxBuf[i].DataLength.ToString() + "\n");
                    MainTextBox.AppendText("\n Data0:" + RxBuf[i].Data0.ToString() + "\n");
                    MainTextBox.AppendText("\n Data7:" + RxBuf[i].Data7.ToString() + "\n");
                }
            }
             */


        }

        // get NC_ATTR_READ_PENDING
        private void button18_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;
            uint Attr = 0;

            Status = NicanDll.ncGetAttribute(Can1ObjHandle, NicanDll.NC_ATTR_READ_PENDING, 4, ref Attr);
            CheckCANStatus(Status, CurMet, "ncGetAttribute 1");
            MainTextBox.AppendText("NC_ATTR_READ_PENDING:" + Attr.ToString() + "\n");

        }

        //read single------------------------------------------------------
        private void button19_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;
            NicanDll.NCTYPE_CAN_STRUCT RxMsg = new NicanDll.NCTYPE_CAN_STRUCT();

            Status = NicanDll.ncRead(Can1ObjHandle, NicanDll.CanStructSize, ref RxMsg);
            CheckCANStatus(Status, CurMet, "ncRead 1");

            MainTextBox.AppendText("\n ----------------------------------------------------\n");
            MainTextBox.AppendText("\n Timestamp:" + RxMsg.TimeStamp.ToString("X") + "\n");
            MainTextBox.AppendText("\n ArbitrationId:" + RxMsg.ArbitrationId.ToString("X") + "\n");
            MainTextBox.AppendText("\n FrameType:" + RxMsg.FrameType.ToString() + "\n");
            MainTextBox.AppendText("\n DataLength:" + RxMsg.DataLength.ToString() + "\n");
            MainTextBox.AppendText("\n Data64:" + RxMsg.Data64.ToString("X") + "\n");
            MainTextBox.AppendText("\n Data7:" + RxMsg.Data7.ToString() + "\n");

        }

        // write Myltiple--------------------------------------------------------
        private void button17_Click(object sender, EventArgs e)
        {
            string CurMet = MethodBase.GetCurrentMethod().Name;
            uint TxBufSize = 4;     // amount of frames to be send
            uint TxBufSizeBytes = TxBufSize * NicanDll.CanStructSize;    // in bytes
            IntPtr TxBufIntPtr;     // pointer to buffer
            NicanDll.NCTYPE_CAN_STRUCT[] TxBuf = new NicanDll.NCTYPE_CAN_STRUCT[TxBufSize];
            int FrameOffset;

            TxBufIntPtr = Marshal.AllocHGlobal((int)TxBufSizeBytes);        // reserve block of memory and get pointer to it

            TxBuf[0].Data64 = 0x010F0F0F0F0F0F01;
            TxBuf[1].Data64 = 0x020F0F0F0F0F0F02;
            TxBuf[2].Data64 = 0x030F0F0F0F0F0F03;
            TxBuf[3].Data64 = 0x040F0F0F0F0F0F04;

            for (int i = 0; i < TxBufSize; i++)
            {
                TxBuf[i].TimeStamp =  0;  // timestamp not supported for 847x
                TxBuf[i].ArbitrationId = CanID | NicanDll.NC_FL_CAN_ARBID_XTD; // to make EXTended 29 bit frame
                TxBuf[i].FrameType = NicanDll.NC_FRMTYPE_DATA;  // or NicanDll.NC_FRMTYPE_REMOTE
                TxBuf[i].DataLength = 8;

                FrameOffset = (int)(i * NicanDll.CanStructSize);

                Marshal.WriteInt64(TxBufIntPtr, FrameOffset + 0,  (long)TxBuf[i].TimeStamp);
                Marshal.WriteInt32(TxBufIntPtr, FrameOffset + 8,  (int) TxBuf[i].ArbitrationId);
                Marshal.WriteByte(TxBufIntPtr,  FrameOffset + 12,       TxBuf[i].FrameType);
                Marshal.WriteByte(TxBufIntPtr,  FrameOffset + 13,       TxBuf[i].DataLength);
                Marshal.WriteInt64(TxBufIntPtr, FrameOffset + 14, (long)TxBuf[i].Data64);
            }

            Status = NicanDll.ncWriteMult(Can0ObjHandle, TxBufSizeBytes, TxBufIntPtr);
            CheckCANStatus(Status, CurMet, "ncWriteMult 0");

        }
        


    }//class Form1
}//namespace
