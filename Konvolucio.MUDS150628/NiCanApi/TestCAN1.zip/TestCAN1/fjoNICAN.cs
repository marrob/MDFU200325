﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace FJO_NICAN_Namespace
{
    //--------------------------------------------------------------------------------------------------------------
    class NI8473    // USB-to-CAN NI8473 adapter
    {

        #region From DLL Imported Functions

        [DllImport("fjoNICANDLL.dll", CallingConvention=CallingConvention.Cdecl)]
        public static extern int MyTest(int x1, int x2);

        [DllImport("fjoNICANDLL.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int MyConfig();

        [DllImport("fjoNICANDLL.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern uint ReadCanID(int x);     //c#-uint == c++ unsigned long

        [DllImport("fjoNICANDLL.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int ReadCanID_2(int x);     //c#-uint == c++ unsigned long

        [DllImport("fjoNICANDLL.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int MyOpen();

        [DllImport("fjoNICANDLL.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int MyWrite();

        [DllImport("fjoNICANDLL.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int MyClose();

        #endregion 

    }// class NI8473

}// namespace
