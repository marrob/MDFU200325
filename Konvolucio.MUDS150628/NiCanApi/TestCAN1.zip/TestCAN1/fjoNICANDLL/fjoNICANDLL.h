// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the FJONICANDLL_EXPORTS
// symbol defined on the command line. This symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// FJONICANDLL_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef FJONICANDLL_EXPORTS
#define FJONICANDLL_API __declspec(dllexport)
#else
#define FJONICANDLL_API __declspec(dllimport)
#endif

// This class is exported from the fjoNICANDLL.dll
/*
class FJONICANDLL_API CfjoNICANDLL {
public:
	CfjoNICANDLL(void);
	// TODO: add your methods here.
};
*/

extern FJONICANDLL_API int nfjoNICANDLL;

FJONICANDLL_API int fnfjoNICANDLL(void);

FJONICANDLL_API LONG CAN_Open( int CanNum, int BdRate );

extern "C"__declspec(dllexport) int MyTest( int x1, int x2 );

//extern "C" __declspec(dllexport) double Add(double a, double b);