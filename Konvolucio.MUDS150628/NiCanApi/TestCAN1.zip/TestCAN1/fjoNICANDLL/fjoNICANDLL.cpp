// fjoNICANDLL.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
//#include "fjoNICANDLL.h"
#include ".\NI-CAN\nican.h"

// This is an example of an exported variable
//FJONICANDLL_API int nfjoNICANDLL=0;

// This is an example of an exported function.
/*
FJONICANDLL_API int fnfjoNICANDLL(void)
{
	return 42;
}
*/
// This is the constructor of a class that has been exported.
// see fjoNICANDLL.h for the class definition
/*
CfjoNICANDLL::CfjoNICANDLL()
{
	return;
}
*/
/*

#define	CAN_A	0
#define	CAN_B	1

#define	CAN_PORT(cannum)	( (cannum == CAN_A) ? "CAN0" : "CAN1" )
#define	NUM_ELEMENTS(a)	(sizeof(a)/sizeof(a[0]))
*/
#define	NUM_ELEMENTS(a)	(sizeof(a)/sizeof(a[0]))
//------------------------------------------------------------------------
// exported function

//FJONICANDLL_API int MyTest( int x1, int x2 )
extern "C" __declspec(dllexport) int MyTest( int x1, int x2 );

int MyTest( int x1, int x2 )
{
	return x1 + x2;
}

//------------------------------------------------------------------------
extern "C" __declspec(dllexport) int MyConfig( void );
int MyConfig( void )
{

	u32 BaudRate = (u32)(1000000);
	NCTYPE_STATUS		Status;
	NCTYPE_ATTRID		AttrIdList[]	= { NC_ATTR_BAUD_RATE,	
											NC_ATTR_START_ON_OPEN,	
											NC_ATTR_READ_Q_LEN,	
											NC_ATTR_WRITE_Q_LEN,	
											NC_ATTR_SINGLE_SHOT_TX,	
											NC_ATTR_SERIES2_FILTER_MODE,	
											NC_ATTR_SERIES2_COMP,	
											NC_ATTR_SERIES2_MASK,	
											NC_ATTR_COMP_STD,	
											NC_ATTR_MASK_STD,	
											NC_ATTR_COMP_XTD,	
											NC_ATTR_MASK_XTD	};

	NCTYPE_UINT32		AttrValueList[]	= { BaudRate,					//NC_ATTR_BAUD_RATE,		 
											NC_FALSE,					//NC_ATTR_START_ON_OPEN,	
											100,						//NC_ATTR_READ_Q_LEN,		 
											10,							//NC_ATTR_WRITE_Q_LEN,	 	
											NC_TRUE,					//NC_ATTR_SINGLE_SHOT_TX,	
											NC_FILTER_SINGLE_EXTENDED,	//NC_ATTR_SERIES2_FILTER_MODE,	
											0x00000000<<3,				//NC_ATTR_SERIES2_COMP,	 	
											0x00000000<<3,				//NC_ATTR_SERIES2_MASK,	 	
											0,							//NC_ATTR_COMP_STD,		 
											0,							//NC_ATTR_MASK_STD,		 
											0,							//NC_ATTR_COMP_XTD,		 
											0		};					//NC_ATTR_MASK_XTD	};	 

	//_CAN_InitTimer();

	Status = ncConfig("CAN0", NUM_ELEMENTS(AttrIdList), AttrIdList, AttrValueList);

	return Status; 
}

//------------------------------------------------------------------------
extern "C" __declspec(dllexport) unsigned long ReadCanID( int x );
unsigned long ReadCanID( int x )
{
	NCTYPE_STATUS		Status;
	//NCTYPE_UINT32		Res1;
	unsigned long		Res;

	//Status = ncGetHardwareInfo(1,1, NC_ATTR_NUM_CARDS, 4, &Res);
	//Status = ncGetHardwareInfo(1,1, NC_ATTR_HW_SERIAL_NUM, 4, &Res);
	Status = ncGetHardwareInfo(1,1, NC_ATTR_NUM_PORTS, 4, &Res);
	
	/*
	NCTYPE_UINT32 CardNumber,
NCTYPE_UINT32 PortNumber,
NCTYPE_ATTRID AttrId,
NCTYPE_UINT32 AttrSize,
NCTYPE_ANY_P AttrPtr);
*/

	return Res;
}

//------------------------------------------------------------------------
extern "C" __declspec(dllexport) int ReadCanID_2( int x );
int ReadCanID_2( int x )
{
	NCTYPE_STATUS		Status;
	//NCTYPE_UINT32		Res1;
	unsigned long		Res;

	//Status = ncGetHardwareInfo(1,1, NC_ATTR_NUM_CARDS, 4, &Res);
	//Status = ncGetHardwareInfo(1,1, NC_ATTR_HW_SERIAL_NUM, 4, &Res);
	Status = ncGetHardwareInfo(5,1, NC_ATTR_HW_SERIAL_NUM, 4, &Res);
	
	/*
	NCTYPE_UINT32 CardNumber,
NCTYPE_UINT32 PortNumber,
NCTYPE_ATTRID AttrId,
NCTYPE_UINT32 AttrSize,
NCTYPE_ANY_P AttrPtr);
*/

	return Status;
}

NCTYPE_OBJH			ObjG = 0;

//------------------------------------------------------------------------
extern "C" __declspec(dllexport) int MyOpen( void );
int MyOpen( void )
{
	NCTYPE_STATUS		Status = 100;

		Status = ncOpenObject("CAN0", &ObjG);

	return Status;
}

//------------------------------------------------------------------------
extern "C" __declspec(dllexport) int MyWrite( void );
int MyWrite( void )
{
	NCTYPE_STATUS		Status = 100;
	NCTYPE_CAN_FRAME	Transmit;
	unsigned int CanId = 5;

		Transmit.ArbitrationId = CanId | 0x20000000;	
		Transmit.IsRemote = FALSE;
		
		Transmit.Data[0] = 0;
		Transmit.Data[1] = 1;
		Transmit.Data[2] = 2;
		Transmit.Data[3] = 3;
		Transmit.Data[4] = 4;
		Transmit.Data[5] = 5;
		Transmit.Data[6] = 6;
		Transmit.Data[7] = 7;
		Transmit.DataLength = 8; //sizeof(Transmit.Data));

		Status = ncWrite( ObjG, sizeof(Transmit), &Transmit);

	return Status;
}

//------------------------------------------------------------------------
extern "C" __declspec(dllexport) int MyClose( void );
int MyClose( void )
{
	NCTYPE_STATUS		Status = 100;

		Status = ncCloseObject( ObjG );

	return Status;
}


/*
// exported function
FJONICANDLL_API LONG CAN_Open( int CanNum, int BdRate ) //u32 BaudRate )
	{
	int x;
	u32 BaudRate = (u32)BdRate;
	NCTYPE_STATUS		Status;
	NCTYPE_ATTRID		AttrIdList[]		= { NC_ATTR_BAUD_RATE,	NC_ATTR_START_ON_OPEN,	NC_ATTR_READ_Q_LEN,	NC_ATTR_WRITE_Q_LEN,	NC_ATTR_SINGLE_SHOT_TX,	NC_ATTR_SERIES2_FILTER_MODE,	NC_ATTR_SERIES2_COMP,	NC_ATTR_SERIES2_MASK,	NC_ATTR_COMP_STD,	NC_ATTR_MASK_STD,	NC_ATTR_COMP_XTD,	NC_ATTR_MASK_XTD	};
	NCTYPE_UINT32		AttrValueList[]	= { BaudRate,				NC_FALSE,					100,						10,						NC_TRUE,						NC_FILTER_SINGLE_EXTENDED,		0x00000000<<3,				0x00000000<<3,				0,						0,						0,						0						};

	//_CAN_InitTimer();

	Status = ncConfig(CAN_PORT(CanNum), NUM_ELEMENTS(AttrIdList), AttrIdList, AttrValueList);

	if (Status < 0) 
		{
		CAN_PrintStat(CanNum, Status, "CAN_Open.ncConfig");
		} // if

	Status = ncOpenObject(CAN_PORT(CanNum), &CAN_Handle[CanNum]);
	if (Status < 0) 
		{
		CAN_PrintStat(CanNum, Status, "CAN_Open.ncOpenObject");
		ncCloseObject(CAN_Handle[CanNum]);
		return -1;
		} // if

	for (x=0; x<NUM_ELEMENTS(AttrIdList); x++)
		{
		Status = ncSetAttribute(CAN_Handle[CanNum], AttrIdList[x], 4, &AttrValueList[x]);
		if (Status < 0) 
			{
			CAN_PrintStat(CanNum, Status, "CAN_Open.ncSetAttribute");
			ncCloseObject(CAN_Handle[CanNum]);
			return -1;
			} // if
		} // for
	CAN_Semaphore[CanNum] = CreateSemaphore(NULL, 1, 1, NULL);

	return 0;
	} // CAN_Open()	*/